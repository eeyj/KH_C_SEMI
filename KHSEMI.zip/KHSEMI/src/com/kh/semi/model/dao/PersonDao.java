package com.kh.semi.model.dao;

public class PersonDao {

}
