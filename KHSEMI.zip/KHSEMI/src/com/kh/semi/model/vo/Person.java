package com.kh.semi.model.vo;

public class Person {

}
